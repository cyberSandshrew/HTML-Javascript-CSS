//Programming Challenge
           // On Your Own:    2.1
           // Description:
                       // Get user's first name, last name, and school name
                       // Parse the first and last name to get initials
                       // Concatenate initials with school name to create the RESULT
                       // Display RESULT
                        
            //Created by: Jerry French  
						//csc240
            //Created on: 3/2/2022,



function createclicked(){
	var first = document.getElementById('firstname');
	var last = document.getElementById('lastname');
	var password = document.getElementById('password');
	var school = document.getElementById('school');

	let firstname, lastname, schoolname;
	firstname = first.value;
	lastname = last.value;
	schoolname = school.value;
	
	let schoolsub = schoolname.split(' ',1);
	
	let logname  = firstname.substring(0, 1) + lastname.substring(0, 1) + schoolsub;
	
	alert("Your Username Is " + logname);

}






function loginclicked() {
	
	var user = document.getElementById('username');
	var pass = document.getElementById('password');
	
	var coruser = logname;
	var corpass = password;
	
	if(user.value == coruser) {
		
		if(pass.value == corpass) {
			window.alert("You May Pass " + user.value);
		
		} else {
			alert("You Fail");
		
		}
		
	} else {
		alert("You Fail");
	
	}
}